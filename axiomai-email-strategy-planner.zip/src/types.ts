export type CampaignObjective = 'product_launch' | 'seasonal_sale' | 'cold_outreach' | 'customer_retention' | 'win_back';

export interface EmailVariant {
  id: string;
  variantName: string;
  conversionType: string;
  subject: string;
  preheader: string;
  body: string;
  targetOutcome: string;
  estimatedCTR: number;
  openRatePrediction: number;
  wordCount: number;
}

export interface CampaignRequest {
  objective: CampaignObjective;
  audience: string;
  tone: string;
  productName: string;
  customDetails?: string;
}

export interface CampaignResponse {
  objective: string;
  audience: string;
  tone: string;
  productName: string;
  variants: EmailVariant[];
  generationTimeMs: number;
  strategicInsight: string;
}

export interface SyncTarget {
  id: string;
  name: string;
  status: 'connected' | 'disconnected' | 'syncing';
  logoType: 'hubspot' | 'mailchimp' | 'klaviyo';
  lastSynced?: string;
  mappedFields: {
    firstName: string;
    email: string;
    companyName: string;
    customField: string;
  };
}
