import { useState } from 'react';
import { BookOpen, Layers, BarChart3, Network, CircleDot, ChevronRight, Check } from 'lucide-react';
import StrategicPlanView from './components/StrategicPlanView';
import BulkGeneratorView from './components/BulkGeneratorView';
import AnalyticsView from './components/AnalyticsView';
import IntegrationsView from './components/IntegrationsView';
import { CampaignResponse } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<'plan' | 'bulk' | 'analytics' | 'sync'>('plan');
  const [activeCampaign, setActiveCampaign] = useState<CampaignResponse | null>(null);

  // Hook to populate default simulated campaign automatically on load so templates are available on day 1
  const initializeDefaultCampaignIfNeeded = () => {
    if (!activeCampaign) {
      setActiveCampaign({
        objective: 'product_launch',
        audience: 'Tech-oriented SMB sales operations managers',
        tone: 'Professional',
        productName: 'Axiom Outreach Hub',
        generationTimeMs: 140,
        strategicInsight: 'Synchronized campaign strategy maps target demographic values perfectly into Benefit-First headers.',
        variants: [
          {
            id: 'variant_a',
            variantName: 'Variant A: Benefit-First Outbound Form',
            conversionType: 'Benefit Value Pitch',
            subject: 'Dynamic workflows designed for sales operations managers',
            preheader: 'An unvarnished guide to speed, precision, and scaling marketing CTRs by 35%.',
            body: `Hi {{First Name}},\n\nIf you are similar to most managers targetting business clients, you spend substantial overhead crafting unique outbound pitches.\n\nWith Axiom Outreach Hub, we automate variant composition while retaining professional voice standards. Our users average 4.2x increases in campaigns curated.\n\nDo you have 2 minutes to trade strategies this week?\n\nBest,\n\n{{Your Name}}`,
            targetOutcome: 'Book initial consultation meetings.',
            estimatedCTR: 4.8,
            openRatePrediction: 22.4,
            wordCount: 65
          },
          {
            id: 'variant_b',
            variantName: 'Variant B: Curiosity and Social Evidence',
            conversionType: 'Case Study Proof',
            subject: 'How a team of 3 accelerated outreach output',
            preheader: 'Details on the email layout that boosted clickthrough rates with zero checklist bloating.',
            body: `Hi {{First Name}},\n\nWe spoke with other sales teams targetting marketing sectors, and they reported empty screens were their core challenge.\n\nUsing Axiom Outreach Hub, they generated 4 parallel variant drafts with one-click.\n\n"The customization is so seamless we sped up sequence formulation instantly."\n\nRead the full outline to see how they scaled without sacrificing tone quality.\n\n[Full Operational Outline]\n\nCheers,\n\n{{Your Name}}`,
            targetOutcome: 'Direct CTR clickthroughs.',
            estimatedCTR: 5.6,
            openRatePrediction: 24.1,
            wordCount: 74
          },
          {
            id: 'variant_c',
            variantName: 'Variant C: Scarcity Opportunity countdown',
            conversionType: 'Urgent Promo Response',
            subject: 'URGENT: Optimizing seasonal outreaches',
            preheader: 'Actionable tactics before high-growth quarter closings.',
            body: `Hi {{First Name}},\n\nWe are currently closing early-access slots for teams using Axiom Outreach Hub.\n\nIf your outgoing multi-track pitches remain manual, you are losing valuable team velocity every day.\n\nEnsure perfect recipient personal structures instantly, prior to quarter closings.\n\n[Secure Campaign Entry Here]\n\nBest,\n\n{{Your Name}}`,
            targetOutcome: 'Drive direct sign-ups.',
            estimatedCTR: 3.9,
            openRatePrediction: 19.8,
            wordCount: 52
          },
          {
            id: 'variant_d',
            variantName: 'Variant D: Founder Lightweight Check-In',
            conversionType: 'Direct conversational Q&A',
            subject: 'Quick query about your outreach sequence, {{First Name}}?',
            preheader: 'Just a casual, unvarnished check on templates effectiveness.',
            body: `Hi {{First Name}},\n\nI was checking out current sales benchmarks and wanted to write personally.\n\nAre you still composing outbound messages manually, or has your team automated personalized draft setups?\n\nI\'d love to outline how we maintain high consistency without wasting your evenings.\n\nLet me know if you are open to a quick reply.\n\nThanks,\n\n{{Your Name}}`,
            targetOutcome: 'Drive direct email replies.',
            estimatedCTR: 6.2,
            openRatePrediction: 28.5,
            wordCount: 60
          }
        ]
      });
    }
  };

  // Initialize once
  initializeDefaultCampaignIfNeeded();

  return (
    <div id="axiom-app-container" className="h-screen w-screen flex flex-col bg-[#F4F7FA] font-sans text-slate-800 overflow-hidden select-none">
      {/* Top Header Row matching High Density specification */}
      <header className="h-14 bg-white border-b border-slate-200 flex items-center justify-between px-6 shrink-0 z-10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-indigo-600 rounded flex items-center justify-center text-white font-black text-sm tracking-tight">
            A
          </div>
          <h1 className="text-sm font-bold tracking-tight text-slate-900 flex items-center gap-2">
            AxiomAI <span className="text-slate-400 font-normal">| Email Strategy Planner</span>
          </h1>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 px-3 py-1 bg-green-50 text-green-700 rounded-full text-[10px] font-bold border border-green-150">
            <CircleDot className="w-3 h-3 text-green-500 fill-green-500 animate-pulse" />
            Strategy Mode Active
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <div className="w-7 h-7 rounded-full bg-slate-200 border border-slate-300 flex items-center justify-center text-[10px] font-bold text-slate-600">
              PM
            </div>
            <span className="text-xs text-slate-500 font-semibold hidden md:inline">Marketing Hub</span>
          </div>
        </div>
      </header>

      {/* Main Column Split Dashboard */}
      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar */}
        <aside className="w-64 bg-white border-r border-slate-200 p-5 flex flex-col shrink-0 gap-6 z-10">
          <section className="flex flex-col gap-3">
            <h3 className="text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-1">
              App Roadmap
            </h3>
            <nav className="space-y-1">
              <button
                onClick={() => setActiveTab('plan')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                  activeTab === 'plan'
                    ? 'bg-indigo-50 text-indigo-700 border border-indigo-100 shadow-xs'
                    : 'text-slate-600 hover:bg-slate-50 border border-transparent'
                }`}
              >
                <div id="nav-item-plan" className="flex items-center gap-2.5">
                  <BookOpen className="w-4 h-4" />
                  Strategic Plan
                </div>
                <ChevronRight className="w-3.5 h-3.5 opacity-60" />
              </button>

              <button
                onClick={() => setActiveTab('bulk')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                  activeTab === 'bulk'
                    ? 'bg-indigo-50 text-indigo-700 border border-indigo-100 shadow-xs'
                    : 'text-slate-600 hover:bg-slate-50 border border-transparent'
                }`}
              >
                <div id="nav-item-bulk" className="flex items-center gap-2.5">
                  <Layers className="w-4 h-4" />
                  Bulk Generator
                </div>
                <ChevronRight className="w-3.5 h-3.5 opacity-60" />
              </button>

              <button
                onClick={() => setActiveTab('analytics')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                  activeTab === 'analytics'
                    ? 'bg-indigo-50 text-indigo-700 border border-indigo-100 shadow-xs'
                    : 'text-slate-600 hover:bg-slate-50 border border-transparent'
                }`}
              >
                <div id="nav-item-analytics" className="flex items-center gap-2.5">
                  <BarChart3 className="w-4 h-4" />
                  Analytics Pro
                </div>
                <ChevronRight className="w-3.5 h-3.5 opacity-60" />
              </button>

              <button
                onClick={() => setActiveTab('sync')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                  activeTab === 'sync'
                    ? 'bg-indigo-50 text-indigo-700 border border-indigo-100 shadow-xs'
                    : 'text-slate-600 hover:bg-slate-50 border border-transparent'
                }`}
              >
                <div id="nav-item-sync" className="flex items-center gap-2.5">
                  <Network className="w-4 h-4" />
                  Integrations
                </div>
                <ChevronRight className="w-3.5 h-3.5 opacity-60" />
              </button>
            </nav>
          </section>

          {/* Target market indicator footer matching design specimen */}
          <section className="mt-auto border-t border-slate-100 pt-4 text-xs text-slate-500 italic flex flex-col gap-1 pr-1 leading-relaxed">
            <span className="text-[9px] uppercase font-bold text-slate-400 not-italic tracking-wider">
              Recipient Segment
            </span>
            <p>
              Target: Marketing Professionals seeking productivity gains via automated multi-email orchestration.
            </p>
          </section>
        </aside>

        {/* Core Center Display View Panel */}
        <main id="axiom-dashboard-body" className="flex-1 p-6 overflow-hidden">
          {activeTab === 'plan' && <StrategicPlanView />}
          {activeTab === 'bulk' && (
            <BulkGeneratorView
              onCampaignGenerated={setActiveCampaign}
              activeCampaign={activeCampaign}
              setActiveCampaign={setActiveCampaign}
            />
          )}
          {activeTab === 'analytics' && <AnalyticsView activeCampaign={activeCampaign} />}
          {activeTab === 'sync' && <IntegrationsView activeCampaign={activeCampaign} />}
        </main>
      </div>
    </div>
  );
}
