import { useState, useMemo } from 'react';
import { ShieldCheck, BarChart3, Terminal, TrendingUp, AlertTriangle, Lightbulb, Zap } from 'lucide-react';
import { CampaignResponse } from '../types';

interface AnalyticsViewProps {
  activeCampaign: CampaignResponse | null;
}

export default function AnalyticsView({ activeCampaign }: AnalyticsViewProps) {
  const [testSubject, setTestSubject] = useState("Quick question about your outbound workflow, {{First Name}}?");

  const subjectEvaluation = useMemo(() => {
    let score = 55;
    const notes: { tag: 'positive' | 'warning' | 'info'; text: string }[] = [];

    // Length check
    if (testSubject.length >= 30 && testSubject.length <= 60) {
      score += 20;
      notes.push({ tag: 'positive', text: `Optimal length (${testSubject.length} chars). Displays fully on mobile screens.` });
    } else if (testSubject.length > 60) {
      score -= 10;
      notes.push({ tag: 'warning', text: `Too long (${testSubject.length} chars). Subject line might get truncated on major email apps (Gmail/Outlook mobile).` });
    } else {
      score += 5;
      notes.push({ tag: 'info', text: `Very brief (${testSubject.length} chars). Ensure it piques enough curiosity.` });
    }

    // Personalization token check
    if (/\{\{\s*First Name\s*\}\}/i.test(testSubject) || /\{\{\s*Name\s*\}\}/i.test(testSubject)) {
      score += 15;
      notes.push({ tag: 'positive', text: "Personalization token identified! Ups CTR by up to 22% average." });
    } else {
      notes.push({ tag: 'warning', text: "Missing custom dynamic variables. Outbound emails perform better with recipient triggers." });
    }

    // Urgency words check
    const urgentWords = ["urgent", "limited", "expires", "today", "now", "quick", "fast", "deal"];
    let matchWord = "";
    const hasUrgent = urgentWords.some((w) => {
      const matched = testSubject.toLowerCase().includes(w);
      if (matched) matchWord = w;
      return matched;
    });

    if (hasUrgent) {
      score += 10;
      notes.push({ tag: 'positive', text: `Incorporate immediate call to action (Word matched: "${matchWord}").` });
    }

    // Spam words check
    const spamWords = ["free", "guaranteed", "cash", "$$$", "earn money", "make money", "100%", "winner"];
    const hasSpam = spamWords.some((w) => testSubject.toLowerCase().includes(w));
    if (hasSpam) {
      score -= 25;
      notes.push({ tag: 'warning', text: "Warning: Contains high-risk vocabulary associated with email spam filters (avoid characters like $$$ or 100% free)." });
    } else {
      score += 5;
    }

    // Cap score at 100, min 10
    const finalScore = Math.min(100, Math.max(10, score));

    return {
      score: finalScore,
      notes
    };
  }, [testSubject]);

  return (
    <div className="h-full flex flex-col gap-6 overflow-y-auto">
      {/* Header */}
      <div className="shrink-0 border-b border-slate-200 pb-3">
        <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
          <BarChart3 className="w-4.5 h-4.5 text-indigo-600" /> Analytics & Subject Line Optimizer
        </h2>
        <p className="text-xs text-slate-500 font-medium">
          Evaluate subject conversion vectors and predict email open performance prior to synchronizing dispatch sequences.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Subject Analyzer View Widget */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 p-5 shadow-sm flex flex-col gap-4">
          <div className="flex justify-between items-center">
            <h3 className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Predictive subject Auditor</h3>
            <span className="flex items-center gap-1 text-[10px] text-indigo-600 font-bold">
              <ShieldCheck className="w-3.5 h-3.5" /> Real-time compliance rating
            </span>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[10px] uppercase font-bold text-slate-500 tracking-wide">Enter Campaign Subject Line</label>
            <input
              type="text"
              value={testSubject}
              onChange={(e) => setTestSubject(e.target.value)}
              className="bg-slate-50 border border-slate-300 rounded-lg text-xs p-3 outline-none text-slate-800 transition-all font-semibold focus:border-indigo-500 focus:bg-white"
            />
          </div>

          {/* Core Score Circle Indicator */}
          <div className="bg-slate-50 border border-slate-100 rounded-lg p-4 flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="relative w-16 h-16 flex items-center justify-center rounded-full bg-indigo-50 border-2 border-indigo-200 shrink-0">
                <span className="text-lg font-extrabold text-indigo-700 tracking-tight">
                  {subjectEvaluation.score}
                </span>
                <span className="text-[8px] text-slate-400 absolute bottom-1.5 uppercase font-mono">Index</span>
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900">
                  {subjectEvaluation.score >= 80 ? "🔥 Outstanding Strength" : subjectEvaluation.score >= 60 ? "📈 Acceptable Conversion State" : "⚠️ Needs Refinement"}
                </h4>
                <p className="text-[11px] text-slate-500 max-w-sm mt-0.5">
                  Based on simulated open thresholds, dynamic personalized factors, and layout length standards.
                </p>
              </div>
            </div>
            <div className="text-center md:text-right">
              <div className="text-xl font-black text-slate-800 tracking-tight">
                ~{(subjectEvaluation.score * 0.28).toFixed(1)}%
              </div>
              <div className="text-[9px] uppercase font-bold text-slate-400 tracking-wider">
                Predicted Open rate
              </div>
            </div>
          </div>

          {/* Audit Notes List */}
          <div className="space-y-2">
            <h4 className="text-[10px] uppercase font-bold text-slate-400 tracking-wide">Optimization Checklist</h4>
            {subjectEvaluation.notes.map((note, idx) => (
              <div
                key={idx}
                className={`p-2.5 rounded-lg border text-[11px] leading-relaxed flex items-start gap-2 ${
                  note.tag === 'positive'
                    ? 'bg-green-50/50 border-green-150 text-green-800'
                    : note.tag === 'warning'
                    ? 'bg-amber-50/50 border-amber-150 text-amber-800'
                    : 'bg-slate-50 border-slate-150 text-slate-700'
                }`}
              >
                <div className="mt-0.5 font-bold shrink-0">
                  {note.tag === 'positive' ? '✓' : note.tag === 'warning' ? '!' : 'i'}
                </div>
                <div>{note.text}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Right side: Applet performance projections */}
        <div className="lg:col-span-5 flex flex-col gap-6">
          {/* Active generated stats */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm flex flex-col gap-4">
            <h3 className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Orchestrated Variant CTR Predictions</h3>
            
            {activeCampaign ? (
              <div className="space-y-3.5">
                {activeCampaign.variants.map((v) => (
                  <div key={v.id} className="border-l-3 border-indigo-500 pl-3.5 flex flex-col gap-1">
                    <div className="text-xs font-bold text-slate-800">{v.variantName.split(':')[0]}</div>
                    <div className="flex justify-between items-center text-[10px] text-slate-500">
                      <span>Formula: {v.conversionType}</span>
                      <span>Target outcome: +{v.estimatedCTR}% clickthroughs</span>
                    </div>
                    {/* Simulated visual progress meter bar */}
                    <div className="w-full bg-slate-100 rounded-full h-1 mt-1 overflow-hidden">
                      <div className="bg-indigo-600 h-full rounded-full" style={{ width: `${v.estimatedCTR * 12}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-slate-400 text-xs">
                No active campaign generated. Run our Bulk Generator simulate workflow first to see CTR indexes here.
              </div>
            )}
          </div>

          {/* Quick tips panel */}
          <div className="bg-slate-900 rounded-xl p-5 border border-slate-800 shadow-lg text-white flex flex-col gap-3">
            <h4 className="text-[10px] font-bold uppercase text-indigo-400 tracking-wider flex items-center gap-1">
              <Zap className="w-3.5 h-3.5" /> Outbound marketing best practices
            </h4>
            <div className="space-y-2 text-[11px] leading-relaxed text-slate-300">
              <p>
                <strong>1. Short Sentences:</strong> Standard mobile screen users skim block text. Keep paragraph heights under 3 lines.
              </p>
              <p>
                <strong>2. One Core CTA:</strong> Avoid asking readers to check 3 different hyperlinks. Direct attention strictly to a single, high-intent landing action.
              </p>
              <p>
                <strong>3. Trust Tokens:</strong> Avoid buzzwords like "unbelievable strategy breakthrough." Ground comments with concrete numbers ("increases throughput by 4.2x") or raw testimonials.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
