import { useState, useMemo } from 'react';
import { Network, Check, Code, RefreshCw, HelpCircle, Loader, Copy, CornerDownRight, Server } from 'lucide-react';
import { CampaignResponse, SyncTarget, EmailVariant } from '../types';

interface IntegrationsViewProps {
  activeCampaign: CampaignResponse | null;
}

export default function IntegrationsView({ activeCampaign }: IntegrationsViewProps) {
  const [selectedTarget, setSelectedTarget] = useState<'hubspot' | 'mailchimp' | 'klaviyo'>('hubspot');
  
  // Choose which variant to mock-export
  const [selectedVariantId, setSelectedVariantId] = useState<string>('variant_a');
  const [isPushing, setIsPushing] = useState(false);
  const [pushedOk, setPushedOk] = useState(false);
  const [copiedPayload, setCopiedPayload] = useState(false);

  // Connection settings
  const [apiKeyInput, setApiKeyInput] = useState("••••••••••••••••••••••••");
  const [selectedList, setSelectedList] = useState("q4_outbound_leads_segment");

  // Dynamic placeholders database structures
  const [fNameTag, setFNameTag] = useState("{{ contact.firstname }}");
  const [emailTag, setEmailTag] = useState("{{ contact.email }}");
  const [companyTag, setCompanyTag] = useState("{{ contact.company }}");

  const activeVariant = useMemo(() => {
    if (!activeCampaign) return null;
    return activeCampaign.variants.find((v) => v.id === selectedVariantId) || activeCampaign.variants[0];
  }, [activeCampaign, selectedVariantId]);

  // Compiled API payload that matches each platform's specification
  const compiledPayloadJson = useMemo(() => {
    if (!activeVariant) return "{}";

    let bodyPlaceholderReplaced = activeVariant.body
      .replace(/\{\{\s*First Name\s*\}\}/g, fNameTag)
      .replace(/\{\{\s*Email\s*\}\}/g, emailTag)
      .replace(/\{\{\s*Company\s*\}\}/g, companyTag)
      .replace(/\{\{\s*Your Name\s*\}\}/g, "Marketing Team")
      .replace(/\{\{\s*Coupon\s*\}\}/g, "SAVE20");

    if (selectedTarget === 'hubspot') {
      return JSON.stringify({
        endpoint: "/marketing/v3/transactional/single-email/send",
        method: "POST",
        headers: {
          "Authorization": `Bearer ${apiKeyInput}`,
          "Content-Type": "application/json"
        },
        payload: {
          emailId: "9827419",
          message: {
            to: emailTag,
            sendId: `axiom_${activeVariant.id}_${Date.now()}`
          },
          contactProperties: {
            firstname: fNameTag,
            email: emailTag,
            company: companyTag
          },
          customState: {
            subject: activeVariant.subject,
            preheader: activeVariant.preheader,
            htmlContent: bodyPlaceholderReplaced.replace(/\n/g, "<br />")
          }
        }
      }, null, 2);
    } else if (selectedTarget === 'mailchimp') {
      return JSON.stringify({
        endpoint: "/3.0/campaigns",
        method: "POST",
        headers: {
          "Authorization": `apikey ${apiKeyInput}-us1`,
          "Content-Type": "application/json"
        },
        payload: {
          type: "regular",
          recipients: {
            list_id: selectedList
          },
          settings: {
            subject_line: activeVariant.subject,
            preview_text: activeVariant.preheader,
            title: `Axiom Generated Campaign: ${activeVariant.variantName}`,
            from_name: "Operations Lead",
            reply_to: "reengage@axiom-outreach.com"
          },
          tracking: {
            opens: true,
            html_clicks: true,
            text_clicks: true
          },
          content_placeholder: {
            plain_text: bodyPlaceholderReplaced,
            html_wrapper: `<div style="font-family:sans-serif;font-size:14px;color:#333333;line-height:1.6;">${bodyPlaceholderReplaced.replace(/\n\n/g, "</p><p>").replace(/\n/g, "<br />")}</div>`
          }
        }
      }, null, 2);
    } else {
      // Klaviyo
      return JSON.stringify({
        endpoint: "/api/v2/campaigns",
        method: "POST",
        headers: {
          "api-key": apiKeyInput,
          "Content-Type": "application/json"
        },
        payload: {
          list_id: selectedList,
          template_id: "axiom_optimized_variant_" + activeVariant.id,
          from_email: "support@axiom-outreach.com",
          from_name: "Customer Outreach Team",
          name: `Axiom_${activeVariant.conversionType}`,
          subject: activeVariant.subject,
          preheader: activeVariant.preheader,
          audiences: [selectedList],
          content: {
            html: `<html><body><p>${bodyPlaceholderReplaced.split('\n\n').join('</p><p>').split('\n').join('<br/>')}</p></body></html>`
          }
        }
      }, null, 2);
    }
  }, [activeVariant, selectedTarget, apiKeyInput, selectedList, fNameTag, emailTag, companyTag]);

  const handlePushSync = () => {
    setIsPushing(true);
    setPushedOk(false);
    setTimeout(() => {
      setIsPushing(false);
      setPushedOk(true);
    }, 1200);
  };

  const copyPayloadToClipboard = () => {
    navigator.clipboard.writeText(compiledPayloadJson);
    setCopiedPayload(true);
    setTimeout(() => setCopiedPayload(false), 1500);
  };

  return (
    <div className="h-full flex flex-col gap-6 overflow-y-auto">
      {/* Header */}
      <div className="shrink-0 border-b border-slate-200 pb-3">
        <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
          <Network className="w-4.5 h-4.5 text-indigo-600" /> Platform Sync & Integration Studio
        </h2>
        <p className="text-xs text-slate-500 font-medium">
          Map custom database metadata and sync generated multi-email campaigns natively with your current distribution systems.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Connection details (High Density Cards) */}
        <div className="lg:col-span-4 flex flex-col gap-5 bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
          <h3 className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">API Connection Credentials</h3>

          {/* Select Platform Tabs */}
          <div className="grid grid-cols-3 gap-2">
            {(['hubspot', 'mailchimp', 'klaviyo'] as const).map((platform) => (
              <button
                key={platform}
                onClick={() => {
                  setSelectedTarget(platform);
                  setPushedOk(false);
                  if (platform === 'hubspot') {
                    setFNameTag("{{ contact.firstname }}");
                    setCompanyTag("{{ contact.company }}");
                  } else {
                    setFNameTag("*|FNAME|*");
                    setCompanyTag("*|COMPANY|*");
                  }
                }}
                className={`py-2 rounded-lg border text-[10px] uppercase font-bold tracking-wider text-center cursor-pointer transition-all ${
                  selectedTarget === platform
                    ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-500 border-slate-200'
                }`}
              >
                {platform}
              </button>
            ))}
          </div>

          {/* Parameter Settings */}
          <div className="space-y-3 pt-2">
            <div className="flex flex-col gap-1">
              <label className="text-[9px] uppercase font-bold text-slate-400 font-mono">Platform API Access Key</label>
              <input
                type="text"
                value={apiKeyInput}
                onChange={(e) => setApiKeyInput(e.target.value)}
                className="bg-slate-50 border border-slate-300 rounded-lg text-xs p-2 outline-none text-slate-700 font-mono focus:border-indigo-500 focus:bg-white"
              />
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-[9px] uppercase font-bold text-slate-400 font-mono">Default Target Segment ID</label>
              <input
                type="text"
                value={selectedList}
                onChange={(e) => setSelectedList(e.target.value)}
                className="bg-slate-50 border border-slate-300 rounded-lg text-xs p-2 outline-none text-slate-700 font-mono focus:border-indigo-500 focus:bg-white"
              />
            </div>

            <div className="pt-2 border-t border-slate-100 flex flex-col gap-2">
              <span className="text-[9px] uppercase font-bold text-slate-400">Placeholder Mapping Rules</span>
              
              <div className="flex flex-col gap-1.5 text-[10px] text-slate-600">
                <div className="flex justify-between items-center bg-slate-50 p-1.5 rounded">
                  <span>First Name Mapping:</span>
                  <input
                    type="text"
                    value={fNameTag}
                    onChange={(e) => setFNameTag(e.target.value)}
                    className="bg-white border rounded px-1.5 text-slate-800 text-right w-36 py-0.5 outline-none font-mono"
                  />
                </div>
                <div className="flex justify-between items-center bg-slate-50 p-1.5 rounded">
                  <span>Email Field Mapping:</span>
                  <input
                    type="text"
                    value={emailTag}
                    onChange={(e) => setEmailTag(e.target.value)}
                    className="bg-white border rounded px-1.5 text-slate-800 text-right w-36 py-0.5 outline-none font-mono"
                  />
                </div>
                <div className="flex justify-between items-center bg-slate-50 p-1.5 rounded">
                  <span>Company Name Mapping:</span>
                  <input
                    type="text"
                    value={companyTag}
                    onChange={(e) => setCompanyTag(e.target.value)}
                    className="bg-white border rounded px-1.5 text-slate-800 text-right w-36 py-0.5 outline-none font-mono"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sync Console */}
        <div className="lg:col-span-8 flex flex-col gap-4">
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm flex flex-col gap-4">
            <h3 className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Launch Outboard Sync Sandbox</h3>

            {activeCampaign ? (
              <div className="space-y-4">
                {/* Select Variant to push */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] uppercase font-bold text-slate-500 tracking-wide">Select Variant to Push</label>
                  <select
                    value={selectedVariantId}
                    onChange={(e) => {
                      setSelectedVariantId(e.target.value);
                      setPushedOk(false);
                    }}
                    className="bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-lg text-xs p-2.5 outline-none text-slate-800 transition-colors font-medium"
                  >
                    {activeCampaign.variants.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.variantName} ({v.conversionType})
                      </option>
                    ))}
                  </select>
                </div>

                {activeVariant && (
                  <div className="p-3 bg-slate-50 border border-slate-150 rounded-lg flex items-start gap-2 text-xs">
                    <CornerDownRight className="w-4 h-4 text-indigo-500 shrink-0 mt-0.5" />
                    <div className="text-slate-600">
                      We'll construct and map <strong className="text-slate-800">{activeVariant.variantName}</strong> using your chosen {selectedTarget} tags.
                    </div>
                  </div>
                )}

                {/* Core Sync Button */}
                <div className="flex flex-col sm:flex-row gap-3 pt-1">
                  <button
                    onClick={handlePushSync}
                    disabled={isPushing}
                    className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs py-3 rounded-lg flex items-center justify-center gap-2 cursor-pointer shadow-sm transition-all"
                  >
                    {isPushing ? (
                      <>
                        <Loader className="w-4 h-4 animate-spin" />
                        Establishing Secure Bridge tunnel...
                      </>
                    ) : (
                      <>
                        <Server className="w-4 h-4 text-indigo-300" />
                        Simulate Push Sequence
                      </>
                    )}
                  </button>
                  <button
                    onClick={copyPayloadToClipboard}
                    className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-lg border border-slate-200 flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {copiedPayload ? <Check className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
                    Copy Outbound API JSON
                  </button>
                </div>

                {/* Success Indicator notification */}
                {pushedOk && (
                  <div className="p-3.5 bg-green-50 border border-green-150 rounded-lg text-green-800 text-xs leading-relaxed flex items-center gap-2.5 animate-fade-in">
                    <Check className="w-5 h-5 text-green-600 shrink-0" />
                    <div>
                      <strong>Synchronization Successful!</strong> Securely packaged and transferred variant headers to {selectedTarget.toUpperCase()}. Raw draft is visible inside your platform campaign folder.
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-6 text-slate-400 text-xs">
                To test synchronization endpoints, run the Bulk Generator first. No active campaign data loaded.
              </div>
            )}
          </div>

          {/* JSON preview logger */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col gap-3">
            <div className="flex justify-between items-center">
              <span className="text-[9.5px] uppercase font-bold text-indigo-400 tracking-wider font-mono flex items-center gap-1">
                <Code className="w-3.5 h-3.5 text-indigo-400" /> API payload stream log ({selectedTarget})
              </span>
              <span className="text-[8px] uppercase tracking-widest text-slate-500 font-mono">
                Content-Type: JSON
              </span>
            </div>
            <pre className="text-[10.5px] text-indigo-100 font-mono overflow-x-auto select-all max-h-[350px] whitespace-pre p-3 bg-slate-950 rounded-lg border border-slate-850">
              {compiledPayloadJson}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
}
