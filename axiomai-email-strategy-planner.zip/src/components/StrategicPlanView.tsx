import { useState } from 'react';
import { developmentPlan } from '../data/planData';
import { FileDown, BookOpen, AlertCircle, Sparkles } from 'lucide-react';

export default function StrategicPlanView() {
  const [activeSection, setActiveSection] = useState<number>(0);

  const exportAsMarkdown = () => {
    let md = `# AxiomAI - Email Strategy Development & Product Plan\n\n`;
    developmentPlan.forEach((section) => {
      md += `## ${section.title}\n*${section.subtitle}*\n\n`;
      section.paragraphs.forEach((p) => {
        md += `${p}\n\n`;
      });
      if (section.metrics) {
        md += `### Core Strategic Indicators\n`;
        section.metrics.forEach((m) => {
          md += `- **${m.label}**: ${m.value} (${m.desc})\n`;
        });
        md += `\n`;
      }
      md += `\n---\n\n`;
    });

    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'AxiomAI_Email_Strategy_Plan.md';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div id="strategic-plan-root" className="h-full flex flex-col gap-6 overflow-y-auto">
      {/* Hero Banner */}
      <div className="bg-slate-900 rounded-xl p-6 text-white flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border border-slate-800 shadow-sm shrink-0">
        <div className="max-w-2xl">
          <div className="flex items-center gap-2 mb-2 text-indigo-400 font-bold text-[10px] uppercase tracking-widest">
            <Sparkles className="w-3.5 h-3.5 animate-pulse" /> Product Strategy Guide
          </div>
          <h2 className="text-xl font-bold tracking-tight text-white mb-1">AxiomAI Development Roadmap</h2>
          <p className="text-xs text-slate-400 max-w-xl">
            A comprehensive, data-backed operational blueprint details how AxiomAI accelerates professional email marketing workflow efficiency by 4.2x.
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={exportAsMarkdown}
            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs px-4 py-2.5 rounded-lg border border-indigo-500 shadow-sm cursor-pointer transition-colors"
          >
            <FileDown className="w-3.5 h-3.5" />
            Export Strategial Plan (.md)
          </button>
        </div>
      </div>

      {/* Main Structural Plan Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Side: Section Navigator */}
        <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200 p-4 shadow-sm flex flex-col gap-3">
          <h3 className="text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-1">Plan Structure</h3>
          <div className="space-y-1.5">
            {developmentPlan.map((section, idx) => (
              <button
                key={idx}
                onClick={() => setActiveSection(idx)}
                className={`w-full text-left p-3 rounded-lg border transition-all text-xs flex flex-col gap-1 cursor-pointer ${
                  activeSection === idx
                    ? 'bg-indigo-50 border-indigo-200 text-indigo-950 font-medium'
                    : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-600'
                }`}
              >
                <div className="flex justify-between items-center w-full">
                  <span className="font-semibold tracking-tight">Section {idx + 1}</span>
                  <span className={`px-1.5 py-0.5 rounded text-[8px] font-bold tracking-wide ${
                    activeSection === idx ? 'bg-indigo-200 text-indigo-800' : 'bg-slate-100 text-slate-500'
                  }`}>
                    {section.title.split('.')[0]}
                  </span>
                </div>
                <div className={`text-[10px] truncate ${activeSection === idx ? 'text-indigo-800' : 'text-slate-400'}`}>
                  {section.subtitle}
                </div>
              </button>
            ))}
          </div>

          <div className="mt-4 pt-4 border-t border-slate-100 bg-slate-50 p-3 rounded-lg flex items-start gap-2 text-[11px] text-slate-600 leading-relaxed">
            <AlertCircle className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
            <div>
              <strong>Proven ROI Strategy:</strong> Built strictly according to industry statistics where customized variant structures yield up to 35% higher campaign CTRs.
            </div>
          </div>
        </div>

        {/* Right Side: Detailed Section View */}
        <div className="lg:col-span-8 bg-white rounded-xl border border-slate-200 p-6 shadow-sm flex flex-col gap-5">
          <div className="flex justify-between items-center border-b border-slate-100 pb-4">
            <div>
              <span className="px-2 py-0.5 bg-indigo-100 text-indigo-700 text-[9px] font-bold rounded tracking-wide uppercase">
                {developmentPlan[activeSection].badge}
              </span>
              <h2 className="text-lg font-bold text-slate-900 mt-1.5">{developmentPlan[activeSection].title}</h2>
              <p className="text-xs text-slate-500 font-medium">{developmentPlan[activeSection].subtitle}</p>
            </div>
            <BookOpen className="w-5 h-5 text-indigo-500 shrink-0" />
          </div>

          {/* Text Content */}
          <div className="space-y-4 text-xs text-slate-600 leading-relaxed">
            {developmentPlan[activeSection].paragraphs.map((para, pIdx) => (
              <p key={pIdx}>
                {para.startsWith('•') ? (
                  <span className="block pl-3 border-l pb-1 border-indigo-200 last:pb-0">{para}</span>
                ) : (
                  para
                )}
              </p>
            ))}
          </div>

          {/* Strategic Metrics (High Density Styling) */}
          {developmentPlan[activeSection].metrics && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6 pt-5 border-t border-slate-100">
              {developmentPlan[activeSection].metrics.map((metric, mIdx) => (
                <div key={mIdx} className="p-3.5 bg-slate-50 border border-slate-100 rounded-lg flex flex-col gap-1.5">
                  <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                    {metric.label}
                  </div>
                  <div className="text-lg font-extrabold text-indigo-600 tracking-tight leading-none">
                    {metric.value}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">
                    {metric.desc}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
