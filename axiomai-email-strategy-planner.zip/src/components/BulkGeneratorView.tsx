import { useState } from 'react';
import { Sparkles, RefreshCw, Copy, Check, Save, Layers, Send, HelpCircle, Loader2, BookOpen } from 'lucide-react';
import { CampaignResponse, EmailVariant, CampaignObjective } from '../types';

interface BulkGeneratorViewProps {
  onCampaignGenerated: (campaign: CampaignResponse) => void;
  activeCampaign: CampaignResponse | null;
  setActiveCampaign: (campaign: CampaignResponse | null) => void;
}

export default function BulkGeneratorView({
  onCampaignGenerated,
  activeCampaign,
  setActiveCampaign,
}: BulkGeneratorViewProps) {
  const [objective, setObjective] = useState<CampaignObjective>('product_launch');
  const [audience, setAudience] = useState('Tech-oriented SMB sales operations managers');
  const [tone, setTone] = useState('Professional');
  const [productName, setProductName] = useState('Axiom Outreach Hub');
  const [customDetails, setCustomDetails] = useState('Emphasize eliminating tedious manual copy drafting blocks and instant CRM sync features.');
  
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [savedSuccessMsg, setSavedSuccessMsg] = useState<string | null>(null);

  const loadingSteps = [
    "Analyzing brand objective & target demographics...",
    "Injecting psychological conversion patterns (FOMO, Benefit-First)...",
    "Running structural predictive audit metrics...",
    "Refining campaign variables and merge tag placements..."
  ];

  const handleGenerate = async () => {
    setIsLoading(true);
    setLoadingStep(0);
    
    // Cycle loading helper messages for real progress feedback
    const interval = setInterval(() => {
      setLoadingStep((prev) => (prev < 3 ? prev + 1 : prev));
    }, 900);

    try {
      const response = await fetch('/api/generate-campaign', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          objective,
          audience,
          tone,
          productName,
          customDetails
        })
      });

      if (!response.ok) {
        throw new Error("Unable to trigger campaign orchestration");
      }

      const data: CampaignResponse & { systemStatus?: string } = await response.json();
      setActiveCampaign(data);
      onCampaignGenerated(data);
    } catch (error) {
      console.error(error);
    } finally {
      clearInterval(interval);
      setIsLoading(false);
    }
  };

  const handleEditField = (vId: string, key: 'subject' | 'preheader' | 'body', text: string) => {
    if (!activeCampaign) return;
    const updatedVariants = activeCampaign.variants.map((v) => {
      if (v.id === vId) {
        const item = { ...v, [key]: text };
        if (key === 'body') {
          item.wordCount = text.split(/\s+/).filter(Boolean).length;
        }
        return item;
      }
      return v;
    });

    setActiveCampaign({
      ...activeCampaign,
      variants: updatedVariants
    });
  };

  const executeCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const saveLocalDraft = (variant: EmailVariant) => {
    const drafts = JSON.parse(localStorage.getItem('axiom_drafts') || '[]');
    drafts.push({
      ...variant,
      productName: activeCampaign?.productName || productName,
      audience: activeCampaign?.audience || audience,
      tone: activeCampaign?.tone || tone,
      savedAt: new Date().toLocaleTimeString()
    });
    localStorage.setItem('axiom_drafts', JSON.stringify(drafts));
    setSavedSuccessMsg(`Successfully saved ${variant.variantName} to drafts archive.`);
    setTimeout(() => setSavedSuccessMsg(null), 2500);
  };

  return (
    <div className="h-full flex flex-col gap-6 overflow-y-auto">
      {/* Header Banner */}
      <div className="shrink-0 flex items-center justify-between border-b border-slate-200 pb-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Layers className="w-4.5 h-4.5 text-indigo-600" /> Multi-Email Variant Generator
          </h2>
          <p className="text-xs text-slate-500 font-medium">
            Draft four optimized campaign copy directions simultaneously based on target marketing psychology.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {activeCampaign && (
            <div className="text-[10px] bg-indigo-50 border border-indigo-100 px-2.5 py-1 rounded text-indigo-700 font-semibold italic">
              {/* @ts-ignore */}
              {activeCampaign.systemStatus || "Loaded Local Baseline"}
            </div>
          )}
        </div>
      </div>

      {savedSuccessMsg && (
        <div className="bg-green-50 border border-green-200 text-green-800 text-xs py-2 px-4 rounded-lg flex items-center gap-2 shrink-0 animate-fade-in">
          <Check className="w-4 h-4 text-green-600" />
          {savedSuccessMsg}
        </div>
      )}

      {/* Grid Layout of parameters vs outputs */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Sidebar inputs */}
        <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200 p-5 shadow-sm flex flex-col gap-4">
          <h3 className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Campaign Strategy Setup</h3>

          <div className="space-y-3.5">
            {/* Objective Selector */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[10px] uppercase font-bold text-slate-500 tracking-wide">Target Objective</label>
              <select
                value={objective}
                onChange={(e) => setObjective(e.target.value as CampaignObjective)}
                className="bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-lg text-xs p-2.5 outline-none text-slate-800 transition-colors font-medium"
              >
                <option value="product_launch">🚀 Product Launch Announcement</option>
                <option value="seasonal_sale">🛍️ Special Promo / Seasonal Offer</option>
                <option value="cold_outreach">🤝 Direct Cold Business Outreach</option>
                <option value="customer_retention">❤️ Retention engagement check-in</option>
                <option value="win_back">🔄 Customer Win-Back reactivation</option>
              </select>
            </div>

            {/* Product Name */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[10px] uppercase font-bold text-slate-500 tracking-wide">Product / service Name</label>
              <input
                type="text"
                value={productName}
                onChange={(e) => setProductName(e.target.value)}
                placeholder="Product, brand, or agency name..."
                className="bg-slate-50 border border-slate-300 rounded-lg text-xs p-2.5 outline-none text-slate-800 transition-all focus:border-indigo-500 focus:bg-white font-medium"
              />
            </div>

            {/* Target Audience */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[10px] uppercase font-bold text-slate-500 tracking-wide">Target Demographics / Persona</label>
              <input
                type="text"
                value={audience}
                onChange={(e) => setAudience(e.target.value)}
                placeholder="e.g. Outbound marketing agency managers, SaaS developers"
                className="bg-slate-50 border border-slate-300 rounded-lg text-xs p-2.5 outline-none text-slate-800 transition-all focus:border-indigo-500 focus:bg-white font-medium"
              />
            </div>

            {/* Tone Dropdown */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[10px] uppercase font-bold text-slate-500 tracking-wide">Brand Voice Tone</label>
              <select
                value={tone}
                onChange={(e) => setTone(e.target.value)}
                className="bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-lg text-xs p-2.5 outline-none text-slate-800 transition-colors font-medium"
              >
                <option value="Professional">💼 Clear, Professional, Authority</option>
                <option value="Warm / Empathetic">🌱 Helpful, Friendly, Human-First</option>
                <option value="Urgent / Direct">⏱️ Action-driven, Scarcity Focused</option>
                <option value="Playful / Conversational">🔥 Engaging, Wit, Creative</option>
              </select>
            </div>

            {/* Custom context */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[10px] uppercase font-bold text-slate-500 tracking-wide">Custom strategy parameters (Optional)</label>
              <textarea
                value={customDetails}
                onChange={(e) => setCustomDetails(e.target.value)}
                rows={3}
                placeholder="Specific selling points, special offers or details to weave into the copy..."
                className="bg-slate-50 border border-slate-300 rounded-lg text-xs p-2.5 outline-none text-slate-800 resize-none transition-all focus:border-indigo-500 focus:bg-white font-medium"
              />
            </div>

            {/* Action Trigger */}
            <button
              onClick={handleGenerate}
              disabled={isLoading}
              className="mt-2 w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-lg font-bold text-xs flex items-center justify-center gap-2 shadow-sm shrink-0 cursor-pointer disabled:bg-indigo-400 group transition-all"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4.5 h-4.5 animate-spin" />
                  Generating Track Variants...
                </>
              ) : (
                <>
                  <Sparkles className="w-4.5 h-4.5 text-indigo-200 group-hover:scale-110 transition-transform" />
                  Simulate Bulk Campaign Copy
                </>
              )}
            </button>
          </div>
        </div>

        {/* Output area - Cards layout */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          {isLoading ? (
            <div className="bg-white rounded-xl border border-slate-200 p-12 text-center flex flex-col justify-center items-center gap-4 min-h-[400px]">
              <div className="p-4 bg-indigo-50 rounded-full animate-bounce">
                <Sparkles className="w-8 h-8 text-indigo-600" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-sm">Axiom Strategic AI Core Orchestration</h3>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  Please hold while our email planning suite generates high-performing conversion variants.
                </p>
              </div>

              {/* Progress Stepper */}
              <div className="w-full max-w-xs mt-3 bg-slate-100 rounded-full h-1.5 overflow-hidden">
                <div
                  className="bg-indigo-600 h-full transition-all duration-700" 
                  style={{ width: `${(loadingStep + 1) * 25}%` }}
                />
              </div>
              <span className="text-[10px] text-indigo-600 font-bold tracking-wide italic">
                {loadingSteps[loadingStep]}
              </span>
            </div>
          ) : activeCampaign ? (
            <div className="flex flex-col gap-6 animate-fade-in">
              {/* Insight Section */}
              <div className="bg-indigo-50 border border-indigo-150 p-4 rounded-xl flex items-start gap-3">
                <BookOpen className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-indigo-950">Axiom Strategic Copywriter Insight</h4>
                  <p className="text-xs text-slate-700 leading-relaxed mt-1">
                    {activeCampaign.strategicInsight}
                  </p>
                </div>
              </div>

              {/* Variants Stack */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {activeCampaign.variants.map((variant) => (
                  <div
                    key={variant.id}
                    className="bg-white rounded-xl border border-slate-200 flex flex-col hover:border-slate-350 hover:shadow-sm transition-all overflow-hidden"
                  >
                    {/* Card Top Details */}
                    <div className="bg-slate-50 border-b border-slate-200 p-3.5 flex items-center justify-between">
                      <div>
                        <h4 className="text-[11px] font-bold text-slate-800">{variant.variantName}</h4>
                        <span className="px-1.5 py-0.5 bg-indigo-100 text-indigo-700 text-[8px] font-bold rounded-md uppercase mt-0.5 inline-block tracking-wide">
                          {variant.conversionType}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => executeCopy(`${variant.subject}\n\n${variant.body}`, variant.id)}
                          className="p-1 px-1.5 hover:bg-slate-200 text-slate-500 rounded text-[10px] font-semibold flex items-center gap-1 cursor-pointer"
                          title="Copy subject and body"
                        >
                          {copiedId === variant.id ? <Check className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5" />}
                          {copiedId === variant.id ? 'Copied' : 'Copy'}
                        </button>
                        <button
                          onClick={() => saveLocalDraft(variant)}
                          className="p-1 hover:bg-slate-200 text-slate-500 rounded cursor-pointer"
                          title="Save Draft locally"
                        >
                          <Save className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Card inputs */}
                    <div className="p-4 flex flex-col gap-3 flex-1">
                      {/* Subject Line */}
                      <div className="flex flex-col gap-1">
                        <label className="text-[9px] uppercase font-bold text-slate-400">Subject Line</label>
                        <input
                          type="text"
                          value={variant.subject}
                          onChange={(e) => handleEditField(variant.id, 'subject', e.target.value)}
                          className="border border-transparent hover:border-slate-200 focus:border-indigo-500 outline-none text-xs text-slate-800 font-semibold p-1 rounded"
                        />
                      </div>

                      {/* Header preheader preview */}
                      <div className="flex flex-col gap-1">
                        <label className="text-[9px] uppercase font-bold text-slate-400 font-mono">Preheader Text</label>
                        <input
                          type="text"
                          value={variant.preheader}
                          onChange={(e) => handleEditField(variant.id, 'preheader', e.target.value)}
                          className="border border-transparent hover:border-slate-200 focus:border-indigo-500 outline-none text-[10px] text-slate-500 p-1 rounded italic"
                        />
                      </div>

                      {/* Dynamic Body */}
                      <div className="flex flex-col gap-1 flex-1">
                        <label className="text-[9px] uppercase font-bold text-slate-400">Email Body Editor</label>
                        <textarea
                          value={variant.body}
                          onChange={(e) => handleEditField(variant.id, 'body', e.target.value)}
                          rows={11}
                          className="border border-slate-150 p-2.5 rounded text-xs text-slate-700 bg-slate-50 focus:bg-white focus:border-indigo-500 outline-none resize-none leading-relaxed font-sans"
                        />
                      </div>
                    </div>

                    {/* KPI Predictors */}
                    <div className="bg-indigo-50/50 border-t border-slate-150 p-3 flex justify-between items-center text-[10px] text-slate-600">
                      <div className="flex gap-4">
                        <div>
                          Open rate estimate:{' '}
                          <strong className="text-slate-800 ml-0.5">{variant.openRatePrediction}%</strong>
                        </div>
                        <div>
                          CTR predict:{' '}
                          <strong className="text-indigo-700 ml-0.5">+{variant.estimatedCTR}%</strong>
                        </div>
                      </div>
                      <div className="text-slate-400 font-mono">{variant.wordCount} words</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-xl border border-slate-200 p-12 text-center flex flex-col justify-center items-center gap-4 min-h-[400px]">
              <Layers className="w-10 h-10 text-slate-300" />
              <div>
                <h3 className="font-bold text-slate-900 text-sm">No Active Campaigns Compiled</h3>
                <p className="text-xs text-slate-400 mt-1 max-w-sm">
                  Configure your product name and objectives on the left side, then run our simulator to generate strategic sequences.
                </p>
              </div>
              <button
                onClick={handleGenerate}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs px-5 py-2 rounded-lg cursor-pointer transition-colors"
              >
                Launch Simulation Now
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
