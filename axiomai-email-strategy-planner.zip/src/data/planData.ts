export interface PlanSection {
  title: string;
  subtitle: string;
  badge: string;
  paragraphs: string[];
  metrics?: { label: string; value: string; desc: string }[];
}

export const developmentPlan: PlanSection[] = [
  {
    title: "1. Purpose and Target Market",
    subtitle: "Eliminating the 'Blank-Page' Friction",
    badge: "1. INTRODUCTION",
    paragraphs: [
      "In modern email marketing, writing speed is often the bottleneck for customer outreach. Marketing teams spend hours debating subject lines, adjusting tone parameters, and tailoring content for diverse reader types. The AI-Powered Multi-Email Generator application transforms this manual, linear process into an automated, systematic curation engine. By providing multi-variant campaigns simultaneously, the tool allows teams to think strategically rather than start with blank screens.",
      "Our target market includes marketing professionals in SMB businesses, high-growth e-commerce entrepreneurs, and outbound scaling teams. These users share a common problem: they require high outreach frequency to maintain pipeline engagement but lack the dedicated copywriting staff to personalize at scale. By combining intelligent templating with instant variant drafting, this tool optimizes workflow throughput without compromising the unyielding standards of message quality and professional voice."
    ],
    metrics: [
      { label: "High Volume", value: "SMBs & Startups", desc: "Target audience needing cost-efficient execution" },
      { label: "Bottleneck", value: "Copywriting Block", desc: "Our core problem target to eliminate" }
    ]
  },
  {
    title: "2. Strategic Feature Matrix & Business Impact",
    subtitle: "High-Efficiency Operations to Boost Engagement",
    badge: "2. INTERACTIVE CORE FEATURES",
    paragraphs: [
      "Rather than attempting to solve every generic marketing task, this platform centers strictly on four targeted, high-value pillars. This focused scope ensures high quality, seamless user experience, and measurable productivity improvements:",
      "• Bulk Email Variant Creation: Teams can input a single core commercial objective—such as a product announcement or holiday promo—and simultaneously output four distinct strategy drafts. Grounded in copywriting methods such as the benefit-driven formula, curiosity gap, or urgent countdown, variants allow marketing teams to immediately cover multiple psychological angles of connection rather than relying on a single, untested message.",
      "• AI-Driven Data Personalization: Instead of simple name-swapping, the generator integrates specific variables like the user's past purchase date, business profile, or geographic region. The engine automatically adapts the surrounding body sentence structure, ensuring that personalization reads naturally rather than feeling like a sterile template replacement.",
      "• Multi-Platform Synchronized Integrations: Outbound emails are useless unless easily launched. The platform includes native, one-click synchronization with standard dispatch hubs like HubSpot and Mailchimp. Users map custom database fields, review the compiled payload, and push drafts directly into their campaign drafts directory with no tedious formatting conversions.",
      "• Predictive Interaction Analytics: Before sending a single message, the tool utilizes lightweight predictive models to rate subject line efficiency, compliance checks, and read-rate indexes. This immediate feedback helps copywriters compress subject lines to optimal lengths and include key action-response verbs before deploying."
    ],
    metrics: [
      { label: "Ideation Time", value: "-80% Reduction", desc: "Drafting draft campaigns takes seconds" },
      { label: "CTR Improvement", value: "+35% Average Lift", desc: "Through hyper-personalization mapping" }
    ]
  },
  {
    title: "3. User Journey Scenarios",
    subtitle: "Practical Real-World Outreach Workflows",
    badge: "3. OPERATIONAL SCENARIOS",
    paragraphs: [
      "Scenario 1: High-Volume Q4 Holiday Campaign Prep. A single marketer at a scaling direct-to-consumer skin-care workspace needs to coordinate five distinct tracks for Black Friday (VIP early access, direct discount, product education, cart recovery, and last-chance urgency). Instead of writing for days, they enter their target demographic, commercial values, and select the prearranged scheduling sequence. AxiomAI's campaign manager drafts the five concurrent tracks, automatically injects recipient-tier discount logic, and schedules the synchronized push directly into HubSpot in under ten minutes.",
      "Scenario 2: Customer Retention Win-Back Strategy. An enterprise B2B company notices active subscribers who haven't logged in for 90 days. The marketer drops the segment list into the AxiomAI data mapping panel. The tool detects the last-active date, tailors a helpful personal check-in from the account executive ('Conversational Relationship' format), and inserts an automatic query regarding specific, previously used product features. The generated variants provide clear, low-friction paths to re-engage, leading to immediate responses."
    ],
    metrics: [
      { label: "Task Flow 1", value: "DTC Marketer", desc: "Concurrent track scheduling in HubSpot" },
      { label: "Task Flow 2", value: "B2B SaaS PM", desc: "Automating passive user win-backs" }
    ]
  },
  {
    title: "4. Value Proposition Summary",
    subtitle: "Transforming Copywriting into Strategic Oversight",
    badge: "4. THE VISION",
    paragraphs: [
      "The ultimate success of outbound campaign outreach lies in its relevance. When a recipient receives an email that addresses their specific operational state, they engage—regardless of whether an AI helped compose it. AxiomAI provides the automation capacity of an enterprise team to small marketing departments and single entrepreneurs.",
      "By removing the mental friction of starting from scratch, we amplify copywriting output. Marketers shift their responsibilities from staring at a blinking prompt, to curate, tweak, and launch. The AxiomAI suite delivers an immediate 4.2x efficiency lift in sequence formulation, ensuring your messages always feel crafted, intentional, and converting."
    ],
    metrics: [
      { label: "Team Velocity", value: "4.2x Faster", desc: "More campaigns curated with identical headcount" },
      { label: "Quality Control", value: "100% Curated", desc: "Users refine and finalize, keeping full oversight" }
    ]
  }
];
