import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Helper function to lazy-initialize Gemini
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return null;
  }
  return new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
}

// Fallback high-impact email compiler based on user options (when API key is absent or failing)
function generateFallbackCampaign(objective: string, audience: string, tone: string, productName: string, customDetails: string = "") {
  const product = productName || "our revolutionary solution";
  const aud = audience || "our targeted audience Group";
  const mood = tone ? `in a ${tone} voice` : "persuasively";

  const genericDetails = customDetails ? `Context: ${customDetails}` : "";

  return {
    objective,
    audience: aud,
    tone: tone || "Professional",
    productName: product,
    generationTimeMs: 140, // simulation of instant compiler
    strategicInsight: `Synchronized B2B outreach strategy formatted for ${aud}. Emphasizing ${objective.replace('_', ' ')} triggers with a balanced layout optimization.`,
    variants: [
      {
        id: "variant_a",
        variantName: "Variant A: Value-Proposition (Benefit-First)",
        conversionType: "Core Benefit Pitch",
        subject: `The honest truth about scaling your outreach for ${product}`,
        preheader: `No fluff. Just a direct strategy to help ${aud} solve their manual workload problems today.`,
        body: `Hi {{First Name}},\n\nIf you are like most professionals working in your role, you're likely spending up to 10 hours a week drafting custom campaigns. It doesn't have to be this way.\n\nWith ${product}, we've designed a systematic workflow specific to ${aud} that accelerates creation without sacrificing engagement. By turning high-quality relevance into a strategic process rather than a manual chore, our users report up to 4.2x increases in throughput.\n\nWant to see exactly how this applies to your current Q4 workflows?\n\nLet's coordinate a quick 5-minute call this Thursday.\n\nBest regards,\n\n{{Your Name}}\n{{Company}}`,
        targetOutcome: "Drive direct response and introductory meetings with high-intent buyers.",
        estimatedCTR: 4.8,
        openRatePrediction: 22.4,
        wordCount: 124
      },
      {
        id: "variant_b",
        variantName: "Variant B: Curiosity & Social Proof",
        conversionType: "Case Study & Authority",
        subject: `How a team of 3 generated 87 campaigns in 2 days (using ${product})`,
        preheader: "An unvarnished look at scale, quality metrics, and the results that followed.",
        body: `Hi {{First Name}},\n\nWhen we spoke with other teams targeting ${aud}, they told us their #1 barrier was 'creative block'—the blank-page friction.\n\nThat's when they started using ${product}. Specifically, they utilized our multi-variant engine to draft 10+ divergent strategic sequences simultaneously.\n\n"We expected the quality to decline, but because the AI incorporates dynamic customer data directly, our response rate actually improved by 35%."\n\nNo manual exporting, no endless spreadsheets. Just clean, highly personalized copy pushed straight to their CRM.\n\nWe mapped out the exact template they used so you can implement it with your team.\n\n[Read the Full Operational Outline]\n\nCheers,\n\n{{Your Name}}\n{{Company}}`,
        targetOutcome: "Educate high-intent prospects and improve click-throughs via third-party validation.",
        estimatedCTR: 5.6,
        openRatePrediction: 24.1,
        wordCount: 145
      },
      {
        id: "variant_c",
        variantName: "Variant C: Direct Urgency & Scarcity",
        conversionType: "Action-Oriented FOMO",
        subject: `Urgent: Streamlining workflows for ${aud}`,
        preheader: "Opportunities to optimize operations before the upcoming quarter close.",
        body: `Hi {{First Name}},\n\nWe are currently closing our early-adopter access window for teams utilizing ${product} within the ${aud} sector.\n\nIf your marketing throughput for the upcoming weeks is not fully automated, you are leaving substantial engagement on the table. Every day spent hand-crafting templates is a day your competitors are scaling personalized touchpoints.\n\nHere is what you get immediate access to:\n- Simultaneous bulk variant creation\n- Advanced predictive CTR scoring\n- One-click native push to HubSpot & Mailchimp\n\nThis limited configuration expires shortly.\n\n[Secure Your Team's Access Now]\n\nBest,\n\n{{Your Name}}\n{{Company}}`,
        targetOutcome: "Generate immediate action and drive signs-ups for limited-time offers.",
        estimatedCTR: 3.9,
        openRatePrediction: 19.8,
        wordCount: 110
      },
      {
        id: "variant_d",
        variantName: "Variant D: Relatable Q&A / Founder Check-In",
        conversionType: "Conversational Trust",
        subject: `Quick question about your ${product} strategy, {{First Name}}?`,
        preheader: "Just a lightweight checkout to verify if your current solution meets expectations.",
        body: `Hi {{First Name}},\n\nI hope this brief note finds you well.\n\nI was reviewing standard outreach metrics for ${aud} and wanted to reach out personally. Are you still running campaigns manually, or have you integrated automated predictive generation into your sequence?\n\nIf you're open to it, I'd love to share the exact layout blueprints we use internally at ${product} to maintain high personalization without consuming your afternoon.\n\nDo you have 2 minutes for a quick reply?\n\nThanks,\n\n{{Your Name}}\n{{Company}}`,
        targetOutcome: "Maximize warm reply rates and initiate authentic conversations with prospects.",
        estimatedCTR: 6.2,
        openRatePrediction: 28.5,
        wordCount: 98
      }
    ]
  };
}

// REST route for generating campaigns using Gemini or falling back
app.post("/api/generate-campaign", async (req, res) => {
  const { objective, audience, tone, productName, customDetails } = req.body;

  if (!objective || !productName) {
    return res.status(400).json({ error: "Campaign objective and product name are required." });
  }

  const ai = getGeminiClient();

  if (!ai) {
    // Return high-quality fallback strategy instantly
    const fallback = generateFallbackCampaign(objective, audience, tone, productName, customDetails);
    return res.json({
      ...fallback,
      systemStatus: "Running on Axiom Local compiler engine (Configure API Secrets to unlock live Gemini generation)."
    });
  }

  try {
    const prompt = `
      You are an expert, data-driven marketing copywriter and strategist. Generate a structured, professional multi-email campaign containing 4 distinct campaign email variants.
      
      Campaign Inputs:
      - Objective: ${objective}
      - Target Audience: ${audience || "General Business Audience"}
      - Tone: ${tone || "Professional and persuasive"}
      - Product Name: ${productName}
      - Custom Context details: ${customDetails || "No additional context"}
      
      We need exactly 4 distinct email formats to enable multi-track variations:
      1. Variant A (Value-Proposition Pitch): Bold benefit metrics, direct problem solving.
      2. Variant B (Curiosity & Case Study): Includes an interest-driven hook and brief customer success anecdote placeholder.
      3. Variant C (Action Urgency): Highlight deadlines, quick optimization opportunity, clear Call to Action (CTA).
      4. Variant D (Conversational Relationship): Short personal outreach form, asking an authentic question from the founder or account executive.
      
      For each variant, produce the following exact schema:
      - id: unique string (e.g. variant_a, variant_b, variant_c, variant_d)
      - variantName: descriptive tag
      - conversionType: e.g. "Value Benefit", "Social Proof", "Urgent CTA", "Direct Reply Query"
      - subject: High-CTR subject line matching the variant's theme
      - preheader: Subtle second line (subject secondary complement)
      - body: The email copy. Use double newlines for spacing. Incorporate merge tags like {{First Name}}, {{Company}}, and {{Your Name}} perfectly. Keep it concise, professional, and within 90-150 words.
      - targetOutcome: Expected tactical response
      - estimatedCTR: A predicted click-through rate percentage (float number between 2.5 and 7.5) reflecting estimated conversion based on best-practices
      - openRatePrediction: A predicted open rate percentage (float number between 15.0 and 32.0)
      - wordCount: Approximate wordcount of the body (integer)
      
      Structure the output as a valid and well-formatted JSON document with the following fields:
      {
        "objective": "${objective}",
        "audience": "${audience || "Standard"}",
        "tone": "${tone || "Professional"}",
        "productName": "${productName}",
        "generationTimeMs": 2500,
        "strategicInsight": "One elegant sentence of high-level strategic guidance tailored specifically to this campaign setup.",
        "variants": [
          // Array of exactly 4 objects matching the parameters above.
        ]
      }
      
      Only return the raw JSON object. Do not wrap in markdown quotes or codeblocks. Ensure it is strict JSON.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const text = response.text || "";
    const cleanText = text.replace(/```json/g, "").replace(/```/g, "").trim();
    const finalData = JSON.parse(cleanText);

    return res.json({
      ...finalData,
      systemStatus: "Live Gemini Engine active — Campaign synthesized in real-time."
    });

  } catch (error: any) {
    console.error("Gemini Generation Error:", error);
    // Graceful error fallback
    const fallback = generateFallbackCampaign(objective, audience, tone, productName, customDetails);
    return res.json({
      ...fallback,
      systemStatus: `Fallback activated (Gemini failed: ${error.message || "Unknown error"}). Your strategy remains functional.`
    });
  }
});

// Start server
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
