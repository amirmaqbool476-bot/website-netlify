import { Check } from 'lucide-react';
import FadeIn from './FadeIn';

export default function Pricing() {
  return (
    <section id="pricing" className="py-24 relative">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <FadeIn>
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl sm:text-4xl font-medium tracking-tight text-white font-geist">
              Consulting & Services
            </h2>
            <p className="mt-4 text-lg text-white/50 font-geist">
              Work directly with me to scale your digital presence.
            </p>
          </div>
        </FadeIn>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Starter */}
          <FadeIn delay={0.1}>
            <div className="rounded-3xl border border-white/10 bg-white/[0.02] p-8 flex flex-col hover:bg-white/[0.04] transition duration-300 h-full">
              <h3 className="text-lg font-medium text-white font-geist">Strategy Session</h3>
              <p className="text-sm text-white/50 mt-2">
                A high-impact audit of your current funnels.
              </p>
              <div className="my-6">
                <span className="text-4xl font-bold text-white font-geist tracking-tight">
                  $350
                </span>
                <span className="text-white/40 ml-1">/hour</span>
              </div>
              <ul className="space-y-4 mb-8 flex-1">
                {[
                  '1-on-1 Video Consultation',
                  'Website & SEO Audit',
                  'Monetization Strategy',
                  'Actionable Post-Call Roadmap'
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-sm text-white/70">
                    <Check className="w-4 h-4 text-orange-500" strokeWidth={3} />
                    {item}
                  </li>
                ))}
              </ul>
              <a href="#" className="block w-full py-3 px-4 rounded-full border border-white/10 bg-white/5 text-center text-sm font-medium text-white hover:bg-white/10 transition">
                Book a Call
              </a>
            </div>
          </FadeIn>

          {/* Growth */}
          <FadeIn delay={0.2}>
            <div className="rounded-3xl border border-orange-500/50 bg-white/[0.04] p-8 flex flex-col relative shadow-2xl shadow-orange-900/10 h-full">
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-orange-500 to-orange-600 text-black text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wide shadow-lg">
                Most Popular
              </div>
              <h3 className="text-lg font-medium text-white font-geist">Mentorship</h3>
              <p className="text-sm text-white/50 mt-2">Guided 12-week intensive accelerator.</p>
              <div className="my-6">
                <span className="text-4xl font-bold text-white font-geist tracking-tight">
                  $2,400
                </span>
                <span className="text-white/40 ml-1">/program</span>
              </div>
              <ul className="space-y-4 mb-8 flex-1">
                {[
                  'Weekly 1-on-1 Strategy Calls',
                  'Content Architecture Blueprint',
                  'Direct Affiliate Partner Intros',
                  'Advanced Email Automation Setup',
                  'Priority Telegram Access'
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-sm text-white/90">
                    <Check className="w-4 h-4 text-orange-400" strokeWidth={3} />
                    {item}
                  </li>
                ))}
              </ul>
              <a href="#" className="block w-full py-3 px-4 rounded-full bg-orange-500 text-center text-sm font-semibold text-black hover:bg-orange-400 transition shadow-lg shadow-orange-500/20">
                Apply Now
              </a>
            </div>
          </FadeIn>

          {/* Enterprise */}
          <FadeIn delay={0.3}>
            <div className="rounded-3xl border border-white/10 bg-white/[0.02] p-8 flex flex-col hover:bg-white/[0.04] transition duration-300 h-full">
              <h3 className="text-lg font-medium text-white font-geist">
                Done For You
              </h3>
              <p className="text-sm text-white/50 mt-2">
                Turn-key digital brand & product creation.
              </p>
              <div className="my-6">
                <span className="text-4xl font-bold text-white font-geist tracking-tight">
                  Custom
                </span>
              </div>
              <ul className="space-y-4 mb-8 flex-1">
                {[
                  'Full Website Design & Dev',
                  'E-commerce Integration',
                  'Custom Digital Product Creation',
                  'SEO & Semantic Silo Setup',
                  'Ongoing Retainer Support'
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-sm text-white/70">
                    <Check className="w-4 h-4 text-orange-500" strokeWidth={3} />
                    {item}
                  </li>
                ))}
              </ul>
              <a href="#" className="block w-full py-3 px-4 rounded-full border border-white/10 bg-white/5 text-center text-sm font-medium text-white hover:bg-white/10 transition">
                Contact Me
              </a>
            </div>
          </FadeIn>
        </div>
      </div>
    </section>
  );
}
