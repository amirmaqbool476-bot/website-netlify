import { ArrowRight } from 'lucide-react';
import FadeIn from './FadeIn';

export default function CTA() {
  return (
    <section className="py-32 relative overflow-hidden">
      <div className="absolute inset-0 bg-orange-900/5"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-orange-500/10 blur-[100px] rounded-full pointer-events-none"></div>

      <FadeIn>
        <div className="mx-auto max-w-4xl px-6 lg:px-8 relative z-10 text-center">
          <h2 className="text-4xl md:text-5xl font-medium tracking-tight text-white font-geist">
            Join the inner circle of digital builders.
          </h2>
          <p className="mt-6 text-lg text-white/60 font-geist max-w-2xl mx-auto">
            Get exclusive essays, deep dives into affiliate marketing strategies, and highly requested resources delivered straight to your inbox every week.
          </p>
          
          <form className="mt-10 mx-auto max-w-md flex flex-col sm:flex-row gap-3">
            <input 
              type="email" 
              placeholder="Enter your email address" 
              required
              className="flex-1 rounded-full border border-white/10 bg-white/5 px-6 py-4 text-sm text-white placeholder-white/40 focus:outline-none focus:border-orange-500/50 focus:ring-1 focus:ring-orange-500/50 transition"
            />
            <button 
              type="submit" 
              className="inline-flex items-center justify-center gap-2 rounded-full bg-orange-500 px-8 py-4 text-sm font-semibold text-black shadow-lg shadow-orange-500/20 hover:bg-orange-400 transition duration-300"
            >
              Subscribe
              <ArrowRight size={16} />
            </button>
          </form>
          <p className="mt-4 text-xs text-white/40">No spam. Unsubscribe anytime.</p>
        </div>
      </FadeIn>
    </section>
  );
}
