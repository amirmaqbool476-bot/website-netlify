import { ArrowRight } from 'lucide-react';
import FadeIn from './FadeIn';

export default function BentoGrid() {
  return (
    <section id="work" className="py-20 bg-neutral-900/20">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row justify-between items-end mb-12 gap-6">
          <FadeIn>
            <div>
              <h2 className="text-3xl font-medium tracking-tight text-white font-geist">
                Featured Resources
              </h2>
              <p className="mt-2 text-white/50 max-w-lg">
                Curated platforms and tools designed to accelerate your digital entrepreneurship journey.
              </p>
            </div>
          </FadeIn>
          <FadeIn delay={0.2}>
            <a href="#" className="text-sm font-medium text-white hover:text-orange-400 transition flex items-center gap-2 group">
              View complete directory
              <span className="bg-white/10 rounded-full p-1 group-hover:bg-orange-500/20 group-hover:text-orange-400 transition">
                <ArrowRight size={16} />
              </span>
            </a>
          </FadeIn>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1 */}
          <FadeIn delay={0.1}>
            <article className="group relative rounded-2xl bg-[#0F0F0F] border border-white/10 overflow-hidden hover:border-orange-500/30 transition duration-500 h-full flex flex-col">
              <div className="aspect-[16/10] overflow-hidden relative">
                <img 
                  src="https://images.unsplash.com/photo-1555421689-491a97ff2040?auto=format&fit=crop&q=80&w=800" 
                  className="object-cover w-full h-full transition duration-700 group-hover:scale-105 opacity-80" 
                  alt="Affiliate Hub" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0F0F0F] via-transparent to-transparent"></div>
                <div className="absolute top-4 left-4">
                  <span className="bg-orange-500 text-black text-[10px] font-bold px-2 py-1 rounded-sm uppercase tracking-wide">
                    Essential
                  </span>
                </div>
              </div>
              <div className="p-6 relative flex flex-col flex-1">
                <h3 className="text-xl font-medium text-white group-hover:text-orange-400 transition">
                  Affiliate Toolkit Directory
                </h3>
                <p className="mt-2 text-sm text-white/50 leading-relaxed flex-1">
                  My heavily researched, hand-picked database of the best SEO tools, CRMs, and marketing platforms. Read in-depth reviews and comparisons.
                </p>
                <div className="mt-6 flex items-center justify-between border-t border-white/5 pt-4">
                  <span className="text-xs text-white/40 font-mono">50+ Reviews</span>
                  <span className="text-xs text-orange-400 font-medium group-hover:underline">Explore Hub</span>
                </div>
              </div>
            </article>
          </FadeIn>

          {/* Card 2 */}
          <FadeIn delay={0.2}>
            <article className="group relative rounded-2xl bg-[#0F0F0F] border border-white/10 overflow-hidden hover:border-orange-500/30 transition duration-500 h-full flex flex-col">
              <div className="aspect-[16/10] overflow-hidden relative">
                <img 
                  src="https://images.unsplash.com/photo-1616469829581-73993eb86b02?auto=format&fit=crop&q=80&w=800" 
                  className="object-cover w-full h-full transition duration-700 group-hover:scale-105 opacity-80" 
                  alt="Digital Store" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0F0F0F] via-transparent to-transparent"></div>
              </div>
              <div className="p-6 relative flex flex-col flex-1">
                <h3 className="text-xl font-medium text-white group-hover:text-orange-400 transition">
                  Creator Templates Store
                </h3>
                <p className="mt-2 text-sm text-white/50 leading-relaxed flex-1">
                  Ready-to-use Notion workspaces, financial planners, and content strategy frameworks designed to save you hundreds of hours.
                </p>
                <div className="mt-6 flex items-center justify-between border-t border-white/5 pt-4">
                  <span className="text-xs text-white/40 font-mono">Instant PDF/Notion</span>
                  <span className="text-xs text-orange-400 font-medium group-hover:underline">Browse Store</span>
                </div>
              </div>
            </article>
          </FadeIn>

          {/* Card 3 */}
          <FadeIn delay={0.3}>
            <article className="group relative rounded-2xl bg-[#0F0F0F] border border-white/10 overflow-hidden hover:border-orange-500/30 transition duration-500 h-full flex flex-col">
              <div className="aspect-[16/10] overflow-hidden relative">
                <img 
                  src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&q=80&w=800" 
                  className="object-cover w-full h-full transition duration-700 group-hover:scale-105 opacity-80" 
                  alt="Blog & Education" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0F0F0F] via-transparent to-transparent"></div>
              </div>
              <div className="p-6 relative flex flex-col flex-1">
                <h3 className="text-xl font-medium text-white group-hover:text-orange-400 transition">
                  Masterclass & Insights
                </h3>
                <p className="mt-2 text-sm text-white/50 leading-relaxed flex-1">
                  Long-form editorial essays, comprehensive guides, and actionable case studies mapping out my journey to a 6-figure online business.
                </p>
                <div className="mt-6 flex items-center justify-between border-t border-white/5 pt-4">
                  <span className="text-xs text-white/40 font-mono">Weekly Updates</span>
                  <span className="text-xs text-orange-400 font-medium group-hover:underline">Read Blog</span>
                </div>
              </div>
            </article>
          </FadeIn>
        </div>
      </div>
    </section>
  );
}
