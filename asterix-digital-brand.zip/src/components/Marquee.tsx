import FadeIn from './FadeIn';

export default function Marquee() {
  return (
    <section className="py-20 border-t border-white/5 bg-white/[0.02]">
      <FadeIn>
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <p className="text-center text-sm font-medium text-white/40 mb-10 font-geist uppercase tracking-widest">
            Partnered with leading digital platforms
          </p>

          <div className="relative w-full overflow-hidden mask-gradient-x">
            <div className="flex w-max gap-12 animate-[marquee_40s_linear_infinite] hover:[animation-play-state:paused]">
              <div className="flex items-center gap-16 opacity-50 grayscale hover:grayscale-0 transition duration-500">
                {/* Simulated partner logos using prominent software brands */}
                <div className="text-xl font-bold font-instrument-serif tracking-widest uppercase">Gumroad</div>
                <div className="text-xl font-bold font-geist tracking-tighter">Stripe</div>
                <div className="text-xl font-bold font-geist">Notion</div>
                <div className="text-xl font-bold italic font-instrument-serif">ConvertKit</div>
                <div className="text-xl font-bold font-geist uppercase tracking-widest">Framer</div>
                <div className="text-xl font-bold font-geist tracking-tight">Vercel</div>
                
                {/* Duplicates for seamless scrolling */}
                <div className="text-xl font-bold font-instrument-serif tracking-widest uppercase ml-16">Gumroad</div>
                <div className="text-xl font-bold font-geist tracking-tighter">Stripe</div>
                <div className="text-xl font-bold font-geist">Notion</div>
                <div className="text-xl font-bold italic font-instrument-serif">ConvertKit</div>
                <div className="text-xl font-bold font-geist uppercase tracking-widest">Framer</div>
                <div className="text-xl font-bold font-geist tracking-tight">Vercel</div>
              </div>
            </div>
          </div>
        </div>
      </FadeIn>
    </section>
  );
}
