import { ArrowRight } from 'lucide-react';
import FadeIn from './FadeIn';

export default function DeepDive() {
  return (
    <section id="process" className="py-32 relative">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          <div className="flex flex-col h-full justify-between sticky top-24">
            <FadeIn direction="right">
              <div>
                <h2 className="text-4xl sm:text-5xl lg:text-6xl font-medium tracking-tight text-white font-geist leading-[0.95]">
                  Strategies that
                  <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-amber-200">
                    scale & convert.
                  </span>
                </h2>
                <p className="mt-8 text-lg text-white/60 font-geist leading-relaxed">
                  I combine an educator's clarity with a marketer's analytical precision. 
                  My approach focuses on building robust digital assets—whether it's an SEO-optimized hub or a high-converting automated funnel.
                </p>

                <div className="mt-12 space-y-8">
                  <div className="group relative pl-8 border-l-2 border-white/10 hover:border-orange-500 transition-colors duration-300">
                    <h3 className="text-lg font-medium text-white group-hover:text-orange-400 transition-colors">
                      SEO & Discoverability
                    </h3>
                    <p className="mt-2 text-sm text-white/50">
                      Technical SEO and keyword-driven content architectures designed to capture high-intent organic search traffic globally.
                    </p>
                  </div>
                  <div className="group relative pl-8 border-l-2 border-white/10 hover:border-orange-500 transition-colors duration-300">
                    <h3 className="text-lg font-medium text-white group-hover:text-orange-400 transition-colors">
                      Conversion Rate Optimization
                    </h3>
                    <p className="mt-2 text-sm text-white/50">
                      Split-testing, analytics, and UX tuning to ensure every digital product page and affiliate review drives maximum yield.
                    </p>
                  </div>
                  <div className="group relative pl-8 border-l-2 border-white/10 hover:border-orange-500 transition-colors duration-300">
                    <h3 className="text-lg font-medium text-white group-hover:text-orange-400 transition-colors">
                      Automated Lead Systems
                    </h3>
                    <p className="mt-2 text-sm text-white/50">
                      Engineering sophisticated email captured funnels with targeted lead magnets, segmenting audiences for personalized nurturing.
                    </p>
                  </div>
                </div>

                <div className="mt-10">
                  <a href="#services" className="inline-flex items-center gap-2 text-sm font-medium text-orange-400 hover:text-orange-300 transition-colors border-b border-orange-400/30 pb-0.5 hover:border-orange-400">
                    Explore My Services
                    <ArrowRight className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </FadeIn>
          </div>

          {/* Right Grid */}
          <div className="grid grid-cols-2 gap-4">
            <FadeIn direction="left" delay={0.1}>
              <div className="space-y-4 translate-y-8">
                <div className="relative aspect-[4/5] rounded-2xl overflow-hidden bg-white/5 group border border-white/10">
                  <img src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=800" className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-105 transition duration-700" alt="Data Analytics" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent"></div>
                  <div className="absolute bottom-4 left-4">
                    <p className="text-xs text-orange-400 font-mono uppercase">Phase 01</p>
                    <p className="text-white font-medium mt-1">Market Analysis</p>
                  </div>
                </div>
                <div className="relative aspect-[4/3] rounded-2xl overflow-hidden bg-white/5 group border border-white/10">
                  <img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800" className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-105 transition duration-700" alt="Strategy" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent"></div>
                  <div className="absolute bottom-4 left-4">
                    <p className="text-xs text-orange-400 font-mono uppercase">Phase 03</p>
                    <p className="text-white font-medium mt-1">Growth Funnels</p>
                  </div>
                </div>
              </div>
            </FadeIn>
            <FadeIn direction="left" delay={0.3}>
              <div className="space-y-4">
                <div className="relative aspect-[4/3] rounded-2xl overflow-hidden bg-white/5 group border border-white/10">
                  <img src="https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&q=80&w=800" className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-105 transition duration-700" alt="Creation" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent"></div>
                  <div className="absolute bottom-4 left-4">
                    <p className="text-xs text-orange-400 font-mono uppercase">Phase 02</p>
                    <p className="text-white font-medium mt-1">Asset Creation</p>
                  </div>
                </div>
                <div className="relative aspect-[4/5] rounded-2xl overflow-hidden bg-white/5 group border border-white/10">
                  <img src="https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&q=80&w=800" className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-105 transition duration-700" alt="Scaling" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent"></div>
                  <div className="absolute bottom-4 left-4">
                    <p className="text-xs text-orange-400 font-mono uppercase">Phase 04</p>
                    <p className="text-white font-medium mt-1">Automate & Scale</p>
                  </div>
                </div>
              </div>
            </FadeIn>
          </div>
        </div>
      </div>
    </section>
  );
}
