export default function Navbar() {
  return (
    <header className="relative z-50 border-b border-white/5 bg-black/50 backdrop-blur-md sticky top-0">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="flex pt-4 pb-4 items-center justify-between">
          <a href="#" className="flex items-center gap-2 group">
            <div className="w-8 h-8 rounded bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center text-black font-bold font-geist tracking-tighter text-lg shadow-lg shadow-orange-500/20 group-hover:shadow-orange-500/40 transition duration-300">
              AM
            </div>
            <span className="font-semibold text-lg tracking-tight font-geist text-white">
              Amir Maqbool
            </span>
          </a>
          
          <nav className="hidden md:flex items-center gap-8 text-sm text-white/70">
            <a className="hover:text-orange-300 transition font-geist" href="#work">Store</a>
            <a className="hover:text-orange-300 transition font-geist" href="#process">About</a>
            <a className="hover:text-orange-300 transition font-geist" href="#pricing">Consulting</a>
            <a className="hover:text-orange-300 transition font-geist" href="#blog">Blog</a>
          </nav>
          
          <div className="flex items-center gap-3">
            <a className="hidden sm:inline-flex text-sm text-white/70 hover:text-white transition font-geist" href="#">
              Creator Login
            </a>
            <a href="#" className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs font-medium hover:bg-white/10 transition font-geist text-orange-100 hover:text-orange-50 group">
              <span className="w-1.5 h-1.5 rounded-full bg-orange-500 group-hover:animate-pulse"></span>
              Join Newsletter
            </a>
          </div>
        </div>
      </div>
    </header>
  );
}
