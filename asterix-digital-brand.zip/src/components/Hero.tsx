import { ChevronRight, Layers, Target, Zap } from 'lucide-react';
import FadeIn from './FadeIn';

export default function Hero() {
  return (
    <section className="sm:pt-16 mb-[80px] pt-12 relative z-10">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="xl:ml-auto xl:mr-auto xl:mt-16 xl:mb-24 text-center max-w-4xl mt-16 mr-auto mb-20 ml-auto">
          <FadeIn>
            <div className="inline-flex items-center gap-2 rounded-full border border-orange-500/20 bg-orange-500/10 px-3 py-1 text-[11px] uppercase tracking-wider font-semibold text-orange-300 mb-6">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-orange-500"></span>
              </span>
              <span className="font-geist">Accepting New Mentorships</span>
            </div>
            
            <h1 className="sm:text-6xl md:text-7xl text-5xl font-medium tracking-tight font-geist mt-2 text-transparent bg-clip-text bg-gradient-to-b from-white via-white/90 to-white/60 pb-2">
              Master the digital
              <br className="hidden sm:block" />
              <span className="lg:italic font-medium text-orange-400 font-instrument-serif relative ml-3">
                 economy.
                <svg className="absolute w-full h-3 -bottom-1 left-0 text-orange-500/30" viewBox="0 0 100 10" preserveAspectRatio="none">
                  <path d="M0 5 Q 50 10 100 5" stroke="currentColor" strokeWidth="2" fill="none"></path>
                </svg>
              </span>
            </h1>
          </FadeIn>

          <FadeIn delay={0.1}>
            <p className="mt-6 text-base sm:text-lg text-white/60 font-geist max-w-2xl mx-auto leading-relaxed">
              Educator | Digital Entrepreneur | Affiliate Marketer.
              <br />
              I help driven individuals build scalable online businesses through strategic content, affiliate marketing, and premium digital products.
            </p>
          </FadeIn>

          <FadeIn delay={0.2}>
            <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-5">
              <div className="btn-wrapper">
                <button className="btn px-6 py-3.5 focus:outline-none" type="button" aria-label="Start Building">
                  <svg className="btn-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" fill="none" stroke="currentColor" strokeWidth="2">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3" />
                  </svg>
                  <div className="txt-wrapper">
                    <div className="txt-1 text-sm font-semibold tracking-wide">
                      <span className="btn-letter">E</span>
                      <span className="btn-letter">x</span>
                      <span className="btn-letter">p</span>
                      <span className="btn-letter">l</span>
                      <span className="btn-letter">o</span>
                      <span className="btn-letter">r</span>
                      <span className="btn-letter">e</span>
                      <span className="pl-2"></span>
                      <span className="btn-letter">H</span>
                      <span className="btn-letter">u</span>
                      <span className="btn-letter">b</span>
                    </div>
                  </div>
                </button>
              </div>
              <div className="inline-block group text-sm rounded-full relative">
                <button className="group inline-flex min-w-[140px] cursor-pointer transition-all duration-300 hover:-translate-y-0.5 hover:text-white border border-white/10 bg-white/5 rounded-full px-5 py-3 relative backdrop-blur-xl items-center justify-center">
                  <span className="z-10 text-xs font-semibold rounded-full mr-2 relative text-white/80 group-hover:text-white transition-colors">
                    View Portfolio
                  </span>
                  <ChevronRight className="w-4 h-4 text-orange-400 transition-transform group-hover:translate-x-1" />
                </button>
              </div>
            </div>
          </FadeIn>
        </div>

        {/* Features Grid */}
        <div className="mt-24">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <FadeIn delay={0.1}>
              <div className="relative p-8 rounded-3xl border border-white/10 bg-white/5 overflow-hidden group hover:border-orange-500/30 transition-all duration-300 hover:-translate-y-1 h-full">
                <div className="absolute inset-0 bg-gradient-to-br from-orange-500/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className="w-12 h-12 rounded-lg bg-orange-500/10 flex items-center justify-center text-orange-400 mb-6 relative z-10">
                  <Target strokeWidth={1.5} size={24} />
                </div>
                <h3 className="text-xl font-medium text-white font-geist mb-3 relative z-10">
                  Affiliate Strategy
                </h3>
                <p className="text-sm text-white/50 leading-relaxed relative z-10">
                  Data-driven affiliate campaigns turning high-quality software and tool recommendations into passive revenue streams.
                </p>
              </div>
            </FadeIn>
            
            <FadeIn delay={0.2}>
              <div className="relative p-8 rounded-3xl border border-white/10 bg-white/5 overflow-hidden group hover:border-orange-500/30 transition-all duration-300 hover:-translate-y-1 h-full">
                <div className="absolute inset-0 bg-gradient-to-br from-orange-500/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className="w-12 h-12 rounded-lg bg-orange-500/10 flex items-center justify-center text-orange-400 mb-6 relative z-10">
                  <Zap strokeWidth={1.5} size={24} />
                </div>
                <h3 className="text-xl font-medium text-white font-geist mb-3 relative z-10">
                  Digital Products
                </h3>
                <p className="text-sm text-white/50 leading-relaxed relative z-10">
                  Premium templates, comprehensive guides, and specialized courses engineered to solve concrete business challenges.
                </p>
              </div>
            </FadeIn>

            <FadeIn delay={0.3}>
              <div className="relative p-8 rounded-3xl border border-white/10 bg-white/5 overflow-hidden group hover:border-orange-500/30 transition-all duration-300 hover:-translate-y-1 h-full">
                <div className="absolute inset-0 bg-gradient-to-br from-orange-500/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className="w-12 h-12 rounded-lg bg-orange-500/10 flex items-center justify-center text-orange-400 mb-6 relative z-10">
                  <Layers strokeWidth={1.5} size={24} />
                </div>
                <h3 className="text-xl font-medium text-white font-geist mb-3 relative z-10">
                  Content Creation
                </h3>
                <p className="text-sm text-white/50 leading-relaxed relative z-10">
                  SEO-optimized editorial content and thought leadership that builds authority and drives organic acquisition.
                </p>
              </div>
            </FadeIn>
          </div>
        </div>
      </div>
    </section>
  );
}
