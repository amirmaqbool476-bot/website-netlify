import { Github, Linkedin, Twitter, Mail, Phone } from 'lucide-react';
import FadeIn from './FadeIn';

export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-[#020202] pt-16 pb-12">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <FadeIn>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            <div className="col-span-1 md:col-span-2">
              <a href="#" className="flex items-center gap-2 mb-6">
                <div className="w-6 h-6 rounded bg-orange-500 flex items-center justify-center text-black font-bold font-geist text-xs">
                  AM
                </div>
                <span className="font-semibold text-xl tracking-tight text-white">
                  Amir Maqbool
                </span>
              </a>
              <p className="text-white/50 text-sm max-w-md leading-relaxed">
                Educator, Affiliate Marketer, and Digital Entrepreneur helping others build profitable online systems through strategy and high-quality templates.
              </p>
              
              <div className="mt-8 flex flex-col gap-3 text-sm text-white/70">
                <a href="mailto:amirmaqbool476@gmail.com" className="hover:text-orange-400 transition flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  amirmaqbool476@gmail.com
                </a>
                <a href="tel:+15551234567" className="hover:text-orange-400 transition flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  +1 (555) 123-4567
                </a>
              </div>

              <div className="mt-8 flex gap-4">
                <a href="#" className="text-white/40 hover:text-white transition group relative p-2">
                  <Twitter className="w-5 h-5 group-hover:text-blue-400 transition" />
                </a>
                <a href="#" className="text-white/40 hover:text-white transition group relative p-2">
                  <Linkedin className="w-5 h-5 group-hover:text-blue-600 transition" />
                </a>
                <a href="#" className="text-white/40 hover:text-white transition group relative p-2">
                  <Github className="w-5 h-5 group-hover:text-gray-300 transition" />
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="text-white font-medium mb-6">Explore</h4>
              <ul className="space-y-4 text-sm text-white/50">
                <li><a href="#" className="hover:text-orange-400 transition">Digital Store</a></li>
                <li><a href="#" className="hover:text-orange-400 transition">Affiliate Reviews</a></li>
                <li><a href="#" className="hover:text-orange-400 transition">Blog & Essays</a></li>
                <li><a href="#" className="hover:text-orange-400 transition">Free Resources</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-medium mb-6">Business</h4>
              <ul className="space-y-4 text-sm text-white/50">
                <li><a href="#" className="hover:text-orange-400 transition">About Me</a></li>
                <li><a href="#" className="hover:text-orange-400 transition">Consulting</a></li>
                <li><a href="#" className="hover:text-orange-400 transition">Sponsorships</a></li>
                <li><a href="#" className="hover:text-orange-400 transition">Contact</a></li>
              </ul>
            </div>
          </div>

          <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-xs text-white/30">
              © {new Date().getFullYear()} Amir Maqbool Digital. All rights reserved.
            </p>
            <div className="flex gap-6 text-xs text-white/30">
              <a href="#" className="hover:text-white transition">Privacy Policy</a>
              <a href="#" className="hover:text-white transition">Terms & Conditions</a>
            </div>
          </div>
        </FadeIn>
      </div>
    </footer>
  );
}
