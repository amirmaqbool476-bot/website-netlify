import BentoGrid from './components/BentoGrid';
import CTA from './components/CTA';
import DeepDive from './components/DeepDive';
import Footer from './components/Footer';
import Hero from './components/Hero';
import Marquee from './components/Marquee';
import Navbar from './components/Navbar';
import Pricing from './components/Pricing';

export default function App() {
  return (
    <div className="min-h-screen bg-[#050505] text-white antialiased">
      {/* Background Layer */}
      <div className="fixed top-0 w-full h-screen -z-10 bg-black">
        <div className="absolute top-0 inset-x-0 h-[500px] w-full bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-orange-900/20 via-black to-black opacity-50"></div>
        <div className="absolute bottom-0 left-0 right-0 top-0 bg-[linear-gradient(to_right,#4f4f4f2e_1px,transparent_1px),linear-gradient(to_bottom,#4f4f4f2e_1px,transparent_1px)] bg-[size:14px_24px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]"></div>
      </div>

      <div className="overflow-hidden relative">
        <Navbar />
        <main>
          <Hero />
          <Marquee />
          <DeepDive />
          <BentoGrid />
          <Pricing />
          <CTA />
        </main>
        <Footer />
      </div>
    </div>
  );
}
